package com.ktdsuniversity.edu.cafe.menu.mgnt.vo;

public class MenuMgntVO {
	
	private String itemName;

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	
}
